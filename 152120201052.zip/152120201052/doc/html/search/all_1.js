var searchData=
[
  ['average1_0',['average1',['../152120201052_8cpp.html#ac2c7adc99693ef2fdf3d207dd0d6b589',1,'152120201052.cpp']]]
];
