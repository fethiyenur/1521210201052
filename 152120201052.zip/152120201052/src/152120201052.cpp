#include <iostream>
#include <fstream>
#include <vector>
using namespace std;

int sum1(const vector<int> numbers) //! @toplama
{
    int sum = 0;
    for (int number : numbers) {
        sum += number;
    }
    return sum;
}

int product1(const vector<int> numbers) //! @carpma
{
    int product = 1;
    for (int number : numbers) {
        product *= number;
    }
    return product;
}

int smallest1(const vector<int> numbers) //! @en kucuk
{
    int smallest = numbers[0]; //! ilk eleman� en kucuk varsaydik
    for (int number : numbers) {
        smallest = min(smallest, number);
    }
    return smallest;
}

int average1(const vector<int> numbers) //! @ortalama
{
    int sum = sum1(numbers);
    return sum / numbers.size();
}

int main() {
    ifstream dosya("input.txt");

    if (!dosya.is_open()) {
        cerr << "File could not be open!" << endl; //! dosyayi bulamadik
        return 1;
    }

    int count;
    dosya >> count;

    vector<int> numbers(count); //! dosyayi okuduk
    for (int i = 0; i < count; ++i) {
        dosya >> numbers[i];
    }

    dosya.close();

    int sum = sum1(numbers);
    int product = product1(numbers);
    int smallest = smallest1(numbers);
    int average = average1(numbers);

    cout << "Sum is " << sum << endl;
    cout << "Product is " << product << endl;
    cout << "Smallest is " << smallest << endl;
    cout << "Average is " << average << endl;

    return 0;
}
